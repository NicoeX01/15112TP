from cmu_112_graphics import *
import time, random    
from aubio import source,onset 
import numpy as np

def almostEqual(d1, d2, epsilon=10**-2.1): #from 15-112 website 
    return (abs(d2 - d1) < epsilon)

def appStarted(app):
    app.time0=time.time()
    app.circles=[]
    app.timeStamps=getOnset("Let's Go, Crimson Knight!.wav",44100) #a list of onset times
    #print(app.timeStamps) 

def timerFired(app):
    diff0=abs(time.time()-app.time0)
    for timeS in app.timeStamps:
        if almostEqual(diff0,float(timeS)):
            app.circles.append(True)
            print(diff0,timeS)
        else:
            app.circles.append(False)      

def drawBoard(app,canvas):
    #print(app.circles)
    for circle in app.circles:
        if circle==True:
            r=10
            cx,cy=random.randint(20,app.width),random.randint(20,app.height)
            canvas.create_oval(cx-r,cy-r,cx+r,cy+r,fill="pink")

################################################################################
#from aubio demo github  https://github.com/aubio/aubio/blob/master/python/demos/demo_onset.py
def getOnset(name,samplerate): #returns list of onset times 
    win_s = 1024//2       # fft size
    hop_s = win_s // 2    # hop size: number of samples between each successive FFT window

    filename = name
    samplerate = samplerate
    s = source(filename, samplerate, hop_s) #creates source object (iterable) 
    samplerate = s.samplerate

    o = onset("default", win_s, hop_s, samplerate)

    # list of onsets, in samples
    onsets = []

    # total number of frames read
    total_frames = 0
    while True:
        samples, read = s()
        if o(samples):
            #print(f'{int(minute)}:{sec}')
            #print('{:0.3f}'.format(o.get_last_s()))
            #print("%f" % o.get_last_s())

            onsets.append(float("%f" % o.get_last_s()))

        total_frames += read
        if read < hop_s: break #reached end of the file 
    #print(len(onsets))
    return onsets

def redrawAll(app,canvas):
    drawBoard(app,canvas)

#print(getOnset("believer.mp3",44100))
#runApp(width=500,height=500)

