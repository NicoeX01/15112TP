from cmu_112_graphics import *
import time 
import math
from pygame import mixer

#from 112 pygame audio https://www.cs.cmu.edu/~112/notes/notes-animations-part4.html
class Sound(object):
    def __init__(self, path):
        self.path = path
        self.loops = 1
        mixer.music.load(path)

    # Returns True if the sound is currently playing
    def isPlaying(self):
        return bool(mixer.music.get_busy())

    # Loops = number of times to loop the sound.
    # If loops = 1 or 1, play it once.
    # If loops > 1, play it loops + 1 times.
    # If loops = -1, loop forever.
    def start(self, loops=1):
        self.loops = loops
        mixer.music.play(loops=loops)

    # Stops the current sound from playing
    def stop(self):
        mixer.music.stop()
    def pause(self):
        mixer.music.pause()
    def unpause(self):
        mixer.music.unpause()
    def isPlaying(self):
        return bool(mixer.music.get_busy())
    
def appStarted(app): 
    mixer.init()
    app.sound = Sound("believer.mp3")
    app.sound.start()

    app.thetaB=math.pi
    app.rPath=50
    app.rCenter=app.rRotating=20
    app.cxRotating=app.width/2+app.rRotating*math.cos(app.thetaB)
    app.cyRotating=app.height/2-app.rRotating*math.sin(app.thetaB)
    app.cxCenter=100 
    app.cyCenter=app.height//2 
    app.cxPath=100
    app.cyPath=app.height//2
    app.rotatingColor="blue"
    app.centerColor="red"
    #app.timerDelay=100 
    app.counter=0
    app.gameOver=False 
    app.blockR=25
    app.marginError=10 #need to calibrate 
    app.pause=False
    
    
def keyPressed(app,event):
    if event.key=="r":
        appStarted(app)
        app.sound.start()
    
    elif event.key=='p':
        if app.sound.isPlaying(): app.sound.pause()
        else: app.sound.unpause()
        app.pause=not app.pause
    else:
        if hit(app,app.height//2,app.blockR,app.cxRotating,app.cyRotating,app.rRotating):
            app.cxCenter+=app.blockR*2
            app.cxRotating+=app.blockR*2
            app.cxPath+=app.blockR*2
            app.thetaB=math.pi

            if app.rotatingColor=="red" and app.centerColor=="blue":
                app.rotatingColor="blue"
                app.centerColor="red"
            elif app.rotatingColor=="blue" and app.centerColor=="red":
                app.rotatingColor="red"
                app.centerColor="blue"
            app.counter+=1

def hit(app,blockC,blockR,cx,cy,r):
    if blockC+blockR+app.marginError>=cy+r and blockC-blockR-app.marginError<= cy-r:
        return True
    return False 

def timerFired(app):
    if app.pause: return
    if app.gameOver==True: 
        app.sound.stop()
        return   
    app.thetaB-=2*126*math.pi/7200
    app.cxRotating=app.cxCenter+app.rPath*math.cos(app.thetaB)
    app.cyRotating=app.cyCenter-app.rPath*math.sin(app.thetaB)
    

def drawPath(app,canvas):
    canvas.create_oval(app.cxPath-app.rPath,app.cyPath-app.rPath,
                        app.cxPath+app.rPath,app.cyPath+app.rPath,
                        outline=app.centerColor)

def drawRotatingCircle(app,canvas):
    canvas.create_oval(app.cxRotating-app.rRotating,app.cyRotating-app.rRotating,
                        app.cxRotating+app.rRotating,app.cyRotating+app.rRotating,fill=app.rotatingColor)
    canvas.create_text(app.cxRotating,app.cyRotating,text=app.counter)
def drawCenterCircle(app,canvas):
    canvas.create_oval(app.cxCenter-app.rCenter,app.cyCenter-app.rCenter,
                        app.cxCenter+app.rCenter,app.cyCenter+app.rCenter,fill=app.centerColor)
    canvas.create_text(app.cxCenter,app.cyCenter,text=app.counter)

def drawBlocks(app,canvas):
    cx0=50
    cy0=app.height//2
    for i in range(20):
        canvas.create_rectangle(cx0-app.blockR,cy0-app.blockR,cx0+app.blockR,
                                cy0+app.blockR,fill="tan")
        cx0+=app.blockR*2

    
def drawText(app,canvas):
    if app.gameOver==True:
        canvas.create_text(app.width//2,app.height//2,text="Game Over!")

def redrawAll(app,canvas):
    drawBlocks(app,canvas)
    #drawPath(app,canvas)
    drawRotatingCircle(app,canvas)
    drawCenterCircle(app,canvas)
    drawText(app,canvas)

runApp(width=1020,height=400)


        
