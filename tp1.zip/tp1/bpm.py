from aubio import source, tempo
from numpy import median, diff
#from aubio gibhub demo (modified a little bit): https://github.com/aubio/aubio/blob/master/python/demos/demo_bpm_extract.py
class bpmDetection():
    def __init__(self,path):
        self.path=path

    def get_file_bpm(self):
        """ Calculate the beats per minute (bpm) of a given file.
            path: path to the file
        """

        samplerate, win_s, hop_s = 44100, 1024, 512

        s = source(self.path, samplerate, hop_s) #creates aubio objeect 
        samplerate = s.samplerate  #gets samplerate 
        o = tempo() #built-in aubio function; gets a list of beats
        # List of beats (times), in samples
        beats = []
        # Total number of frames read
        total_frames = 0

        while True:
            samples, read = s()
            is_beat = o(samples)
            if is_beat:
                this_beat = o.get_last_s()
                beats.append(this_beat)
            total_frames += read
            if read < hop_s: #reached end of the file 
                break

        def beats_to_bpm(beats, path):
            # if enough beats are found, convert to periods then to bpm
            if len(beats) > 1:
                if len(beats) < 4:
                    print("few beats found in {:s}".format(path))
                bpms = 60./diff(beats)  #gets a list of bpm 
                #print(bpms)
                return int(median(bpms)) #gets average using numpy 
            else:
                print("not enough beats found in {:s}".format(path))
                return 0
        return beats_to_bpm(beats, self.path)
