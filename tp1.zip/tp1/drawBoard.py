from cmu_112_graphics import *
from onsetDetection import Onset

class Board(object):
    def __init__(self,path):
        self.path=path 
        self.emptyColor="azure"
        #self.speed= speed of orbiting circle 
        
    def makeBoard(self):
        self.onsetTimes=Board.makeOnsetTimes(self.path)
        length=len(self.onsetTimes)
        self.board=[[]*40 for row in range(20)]
        x0=350
        y0=d=50
        for row in range(20):
            for col in range(40):
                self.board[row].append((self.emptyColor,x0+col*d,y0+row*d))

        for col in range(20):
            self.board[3][col]=("black",x0+col*d,y0+3*d)
        for col in range(19,40):
            self.board[4][col]=("black",x0+col*d,y0+4*d)

        return self.board
    @staticmethod 
    def makeOnsetTimes(filename):
        sound=Onset(filename)
        return sound.getOnsetTimes()

