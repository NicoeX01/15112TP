from cmu_112_graphics import *
import time 
import math
from pygame import mixer       
from playMusic import Sound   #pygame: plays music 
from bpm import bpmDetection  #gets bpm 
from drawBoard import Board  #makes the map  

'''
updates:
- created classes for beat and onset detection, board, pygame audio 
- created base board 
- added sidescroll feature; works in all ways 
- added game over conditions (partially working)

need to add/fix:
- gameover: % completed 
- gameover: doesn't end when it's supposed to (when hits empty space)
- board generation 
- delay start + countdown before playing music 
- colomn not working bc of left margin (get col)
- rotating circle should start where it left off 
'''

def appStarted(app): 
    #creates a 2D grid; serves as map 
    b=Board("A Dance of Fire and Ice.wav") #need to make a list of songs for levels
    app.board=b.makeBoard()
    app.emptyColor=b.emptyColor
    app.rows, app.cols, app.cellSize, app.margin=gameDimensions(app.board)
    app.leftMargin=app.width//2
    app.boardWidth=app.boardHeight=1100
    app.scrollX=app.scrollY=0

    #play music
    mixer.init()
    a = mixer.Sound("A Dance of Fire and Ice.wav")
    sound = Sound("A Dance of Fire and Ice.wav")
    app.songLength=a.get_length() 
    app.sound = Sound("A Dance of Fire and Ice.wav")
    app.sound.start()
    app.initial=time.time()
    app.duration=0
    app.stopDisplay=True

    app.music=bpmDetection("A Dance of Fire and Ice.wav")
    app.bpm=app.music.get_file_bpm()
    
    #circles 
    app.thetaB=0
    app.rPath=50
    app.rCenter=app.rRotating=20
    app.cxRotating=app.width/2+app.rRotating*math.cos(app.thetaB)
    app.cyRotating=app.height/2-app.rRotating*math.sin(app.thetaB)
    app.cxCenter=app.cxPath=app.leftMargin+app.cellSize//2
    app.cyCenter=app.cyPath=app.height//2-app.cellSize//2 
    app.rotatingColor="turquoise"
    app.centerColor="salmon"
    #app.timerDelay=100 
    app.counter=0

    app.gameOver=False 
    app.marginError=10 #need to calibrate 
    app.pause=False

def gameDimensions(board):
    row=len(board)
    col=len(board[0])
    cellSize=50
    margin=50
    return row,col,cellSize,margin

def keyPressed(app,event):
    if event.key=="r": 
        appStarted(app) 
    elif app.gameOver: return
    elif event.key=='p':
        if app.sound.isPlaying(): app.sound.pause()
        else: app.sound.unpause()
        app.pause=not app.pause
    else:
        if hit(app,app.cxRotating,app.cyRotating): #if circle hits right block 
            try:
                dx,dy,direction=getDirection(app,app.cxCenter,app.cyCenter,app.cxRotating,app.cyRotating)
            except:
                app.gameOver=True
            '''
            app.cxCenter+=dx*app.cellSize
            app.cyCenter+=dy*app.cellSize
            app.cxRotating+=app.cellSize
            app.cxPath+=dx*app.cellSize
            app.cyPath+=dy*app.cellSize
            '''
            if app.gameOver==True: return 
            app.thetaB=math.pi
            modifyScroll(app,direction) #changes scrollX & scrollY based on direction
        
            #changes color of rotating circle
            if app.rotatingColor=="salmon" and app.centerColor=="turquoise":
                app.rotatingColor="turquoise"
                app.centerColor="salmon"
            elif app.rotatingColor=="turquoise" and app.centerColor=="salmon":
                app.rotatingColor="salmon"
                app.centerColor="turquoise"
            app.counter+=1   
        else: 
            app.game=True

            return

def modifyScroll(app,direction):
    if direction=="right":
        app.scrollX-=50
    elif direction=="left":
        app.scrollX+=50
    elif direction=="up":
        app.scrollY+=50
    elif direction=="down":
        app.scrollY-=50
    print(app.scrollX,app.scrollY)

def getCellBounds(app, row, col): #from 112 lecture notes on grids; model to view 
    gridWidth  = app.boardWidth - 2*app.margin
    gridHeight = app.boardHeight - 2*app.margin
    cellWidth = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    x0 = app.margin + col * cellWidth
    x1 = app.margin + (col+1) * cellWidth
    y0 = app.margin + row * cellHeight
    y1 = app.margin + (row+1) * cellHeight
    return (x0, y0, x1, y1)

def getCell(app, x, y): #from https://www.cs.cmu.edu/~112/notes/notes-animations-part2.html#exampleGrids
    gridWidth  = app.boardWidth - 2*app.margin 
    gridHeight = app.boardHeight - 2*app.margin
    cellWidth  = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    row = int((y - app.margin) / cellHeight)
    col = int((x - app.margin) / cellWidth)
    return row,col 

def hit(app,cx,cy): #check if rotating circle is in correct position (colored block)
    row,col=getCell(app,cx,cy)
    color,x,y=app.board[row][col-14]
    print(color,row,col)
    if color!=app.emptyColor:
        return True
    app.gameOver=True
    return False 

def getDirection(app,x0,y0,newX,newY): #checks direction for new position 
    row0,col0=getCell(app,x0,y0)
    row1,col1=getCell(app,newX,newY)
    if row1>row0 and col0==col1:
        return 0,1,"down"
    if row1<row0 and col0==col1:
        return 0,-1,"up"
    if row1==row0 and col0>col1:
        return -1,0,"left"
    if row1==row0 and col0<col1:
        return 1,0,"right"

def timerFired(app):
    if app.gameOver and app.stopDisplay: 
        app.duration=time.time()-app.initial
        app.sound.stop()
        app.stopDisplay=False 
        return    
    if app.pause: return
     
    app.thetaB-=2*150*math.pi/7200
    app.cxRotating=app.cxCenter+app.rPath*math.cos(app.thetaB)
    app.cyRotating=app.cyCenter-app.rPath*math.sin(app.thetaB)         

################################################################################
def drawPath(app,canvas):
    if app.gameOver:return 
    canvas.create_oval(app.cxPath-app.rPath,app.cyPath-app.rPath,
                        app.cxPath+app.rPath,app.cyPath+app.rPath,
                        outline=app.centerColor)

def drawRotatingCircle(app,canvas):
    if app.gameOver:return 
    canvas.create_oval(app.cxRotating-app.rRotating,app.cyRotating-app.rRotating,
                        app.cxRotating+app.rRotating,app.cyRotating+app.rRotating,fill=app.rotatingColor)
    canvas.create_text(app.cxRotating,app.cyRotating,text=app.counter)

def drawCenterCircle(app,canvas):
    if app.gameOver:return 
    canvas.create_oval(app.cxCenter-app.rCenter,app.cyCenter-app.rCenter,
                        app.cxCenter+app.rCenter,app.cyCenter+app.rCenter,fill=app.centerColor)
    canvas.create_text(app.cxCenter,app.cyCenter,text=app.counter)

def drawBoard(app,canvas):
    if not app.gameOver:
        for row in range(app.rows):
            for col in range(app.cols):
                color,x0,y0=app.board[row][col]
                x1,y1=x0+app.cellSize,y0+app.cellSize
                canvas.create_rectangle(x0+app.scrollX, y0+app.scrollY, x1+app.scrollX, y1+app.scrollY, 
                                        fill=color, width=1,outline="blue")

def drawText(app,canvas):
    if app.gameOver:
        canvas.create_text(app.width//2,1.5*app.height//4,text="Game Over!",font="Courier 40 bold")
        canvas.create_text(app.width//2,2*app.height//4,text="Press r to continue",font="Courier 20 bold")
        canvas.create_text(app.width//2,3*app.height//4,text=f'{100*app.duration//app.songLength}%')
    else:
        canvas.create_text(app.width//2,app.margin,text="Listen for the beats...",font="Courier 20")

def redrawAll(app,canvas):
    drawBoard(app,canvas)
    drawPath(app,canvas)
    drawRotatingCircle(app,canvas)
    drawCenterCircle(app,canvas)
    drawText(app,canvas)

runApp(width=700,height=500)




        
